import asyncio
from sbb_b import sbb_b 
from ..helpers.utils import reply_id

#الملف من قبل سورس ممنوع اي احد يسرقة او ينسبه لنفسه !
#فقط الي كاتبلك عليهن غيرهن اما غيرها لاتلعب بيهن !
#-------------------------------------------------------
@sbb_b.on(admin_cmd(outgoing=True, pattern="اجمد كده"))
async def jepmeme(ALJoker):
  Jep = await reply_id(ALJoker)
  url = f"https://t.me/MemesVoices/20"
  await ALJoker.client.send_file(ALJoker.chat_id,url,caption="",parse_mode="html",reply_to=Jep)
  await ALJoker.delete()
  
@sbb_b.on(admin_cmd(outgoing=True, pattern="لماذا نحن هنا"))
async def jepmeme(ALJoker):
  Jep = await reply_id(ALJoker)
  url = f"https://t.me/husjsbjxo/3"
  await ALJoker.client.send_file(ALJoker.chat_id,url,caption="",parse_mode="html",reply_to=Jep)
  await ALJoker.delete()
  
@sbb_b.on(admin_cmd(outgoing=True, pattern="بووم"))
async def jepmeme(ALJoker):
  Jep = await reply_id(ALJoker)
  url = f"https://t.me/husjsbjxo/110"
  await ALJoker.client.send_file(ALJoker.chat_id,url,caption="",parse_mode="html",reply_to=Jep)
  await ALJoker.delete()  
  
@sbb_b.on(admin_cmd(outgoing=True, pattern="خلصانه"))
async def jepmeme(ALJoker):
  Jep = await reply_id(ALJoker)
  url = f"https://t.me/MemesVoices/22"
  await ALJoker.client.send_file(ALJoker.chat_id,url,caption="",parse_mode="html",reply_to=Jep)
  await ALJoker.delete()    
  
@sbb_b.on(admin_cmd(outgoing=True, pattern="تعبان"))
async def jepmeme(ALJoker):
  Jep = await reply_id(ALJoker)
  url = f"https://t.me/MemesVoices/23"
  await ALJoker.client.send_file(ALJoker.chat_id,url,caption="",parse_mode="html",reply_to=Jep)
  await ALJoker.delete()      
  
@sbb_b.on(admin_cmd(outgoing=True, pattern="يلاهوي"))
async def jepmeme(ALJoker):
  Jep = await reply_id(ALJoker)
  url = f"https://t.me/MemesVoices/10"
  await ALJoker.client.send_file(ALJoker.chat_id,url,caption="",parse_mode="html",reply_to=Jep)
  await ALJoker.delete()        
  
@sbb_b.on(admin_cmd(outgoing=True, pattern="انا رمضان جانا"))
async def jepmeme(ALJoker):
  Jep = await reply_id(ALJoker)
  url = f"https://t.me/MemesVoices/5"
  await ALJoker.client.send_file(ALJoker.chat_id,url,caption="",parse_mode="html",reply_to=Jep)
  await ALJoker.delete()          
  
@sbb_b.on(admin_cmd(outgoing=True, pattern="يا حلو"))
async def jepmeme(ALJoker):
  Jep = await reply_id(ALJoker)
  url = f"https://t.me/MemesVoices/18"
  await ALJoker.client.send_file(ALJoker.chat_id,url,caption="",parse_mode="html",reply_to=Jep)
  await ALJoker.delete()         

@sbb_b.on(admin_cmd(outgoing=True, pattern="عاوزين نعملك بني ادم"))
async def jepmeme(ALJoker):
  Jep = await reply_id(ALJoker)
  url = f"https://t.me/MemesVoices/13"
  await ALJoker.client.send_file(ALJoker.chat_id,url,caption="",parse_mode="html",reply_to=Jep)
  await ALJoker.delete()              
  
@sbb_b.on(admin_cmd(outgoing=True, pattern="ربنا نصرني"))
async def jepmeme(ALJoker):
  Jep = await reply_id(ALJoker)
  url = f"https://t.me/MemesVoices/29"
  await ALJoker.client.send_file(ALJoker.chat_id,url,caption="",parse_mode="html",reply_to=Jep)
  await ALJoker.delete()                
  
@sbb_b.on(admin_cmd(outgoing=True, pattern="اتكلم بادب"))
async def jepmeme(ALJoker):
  Jep = await reply_id(ALJoker)
  url = f"https://t.me/MemesVoices/4"
  await ALJoker.client.send_file(ALJoker.chat_id,url,caption="",parse_mode="html",reply_to=Jep)
  await ALJoker.delete()                  