from sample_config import Config

#لمنصبي السيرفر

class Development(Config):
    # احصل على الايبيات من الموقع the my.telegram.org
    APP_ID = 12429107
    API_HASH = "eb06d4abfb49dc3eeb1aeb98ae0f581e"
    # اسم حسابك
    ALIVE_NAME = "hi"
    # اصنع رابط تخزين منelephantsql
    DB_URI = "postgres://qlvqavqq:nFN4MCTo2AEHVL-yefKrjrIE5m2D39Km@john.db.elephantsql.com/qlvqavqq"
    # كود سيشن تيليثون (كود تيرمكس )
    STRING_SESSION = "1ApWapzMBu1qVdk_LOeVC7MG6nJl1bZjTwbnwg8H5kd4bL1KSfDozMCgVVSdzKVH4VYoaZKiu1i3ErEsu-sqq7l0rAwDgzeCOdf5D7DO1Ffndm-VojTtm5hSaupbAaWi-5C8-pSGzPFs92wqSqNjKGdQbjfP4K_kGw7H1Qpv9UnFKkliCqInKQZDMGYow8pbvpJORcYuPx9E8W6WlYx40RNEL2yWIMOGiyeEInuPYaoa0hJnq4OXXX4ktm8jfPYEt2pMDOemmGfm6zM_u2qIucMTRZ3hI_QXw1krUUq6kUyzuq-4DyGwMp9CAYJ16Ansg4rl-xmyXI9lqAiVZBrjGv5B7HJeBG2E="
    # اوكن بوتك
    TG_BOT_TOKEN = "5690631045:AAH7qiS_83h71ixI4hkDqvw-JvmzZyBTpB4"
    # هنا اصنع كروب خاص وضع ايديه هنا
    PRIVATE_GROUP_BOT_API_ID = -1001669604913
    # لا تغيرها
    COMMAND_HAND_LER = "."
    # لا تغيرها
    SUDO_COMMAND_HAND_LER = "."
    # رابط ملفات الاوامر الاضافيه لا تغيره
    EXTERNAL_REPO = "https://github.com/sbb_b/JmPlugins"
